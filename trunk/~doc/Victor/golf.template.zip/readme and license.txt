********************************************************************
	SPYKA WEBMASTER - HTTP://WWW.SPYKA.NET
	FREE WEB TEMPLATES AND RESOURCES FOR WEBMASTERS
********************************************************************

This is a free web template by spyka webmaster (http://www.spyka.net)



1. Customizing this template
-----------------------------------------
To change the text, content, links etc. open the index.html in your preferred HTML editor, 
whether it be notepad, dreamweaver or frontpage.

To change the CSS open styles.css in a HTML/CSS editor and change the appropriate 
values to suit your needs.

Need more help? Try our webmaster forums - http://community.spyka.co.uk


2. Paid template customisation
-----------------------------------------
Our partner site, spyka Web Design, can customise this template for you from �10, that can include changing images, 
colour schemes, navigation links, adding content and page structure changes.

Check out spykawebdesign.com for more info.


3. Terms of use/License
-----------------------------------------
This template has been released under a Creative Commons Attribution license, this means you can use the template as long
as a link back to spyka Webmaster remains in the footer. This condition can be waived by purchasing a template license for �4.00 (See 4. Template License in this document)

For more information of the license: http://creativecommons.org/licenses/by/3.0/


4. Template License
-----------------------------------------
The link back to spyka.net and any other copyright/information relating to spyka.net can 
be removed with the purchase of a template license. A license costs �4.00 (Approx $6USD) 
per template per site and gives the site owner/webmaster the right to remove this information.

To purchase a license or for more information see: http://www.spyka.net/licensing


5. Other information
-----------------------------------------
Please contact us if you need more information about template licences, use of our templates
or other queries - spyka.net/contact
